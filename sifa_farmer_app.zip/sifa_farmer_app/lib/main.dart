import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'South India Farmers Association',
      debugShowCheckedModeBanner: false,
      home: RegistrationPage(),
    ),
  );
}

class RegistrationPage extends StatefulWidget {
  @override
  _RegistrationPageState createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _otpController = TextEditingController();
  final _aadharController = TextEditingController();
  final _locationController = TextEditingController();
  final _emergencyContactController = TextEditingController();

  final _nameFocus = FocusNode();
  final _mobileFocus = FocusNode();
  final _otpFocus = FocusNode();
  final _aadharFocus = FocusNode();
  final _locationFocus = FocusNode();
  final _emergencyContactFocus = FocusNode();

  bool _nameTouched = false;
  bool _mobileTouched = false;
  bool _otpTouched = false;
  bool _aadharTouched = false;
  bool _locationTouched = false;
  bool _emergencyTouched = false;

  File? _profileImage;
  File? _idDocument;

  String? _gender;
  String? _maritalStatus;
  String? _religion;
  String? _occupation;
  String? _skill;
  String? _bloodGroup;

  @override
  void initState() {
    super.initState();
    _addFocusListeners();
  }

  void _addFocusListeners() {
    _nameFocus.addListener(() {
      if (!_nameFocus.hasFocus) setState(() => _nameTouched = true);
    });
    _mobileFocus.addListener(() {
      if (!_mobileFocus.hasFocus) setState(() => _mobileTouched = true);
    });
    _otpFocus.addListener(() {
      if (!_otpFocus.hasFocus) setState(() => _otpTouched = true);
    });
    _aadharFocus.addListener(() {
      if (!_aadharFocus.hasFocus) setState(() => _aadharTouched = true);
    });
    _locationFocus.addListener(() {
      if (!_locationFocus.hasFocus) setState(() => _locationTouched = true);
    });
    _emergencyContactFocus.addListener(() {
      if (!_emergencyContactFocus.hasFocus) setState(() => _emergencyTouched = true);
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _profileImage = File(picked.path));
    }
  }

  Future<void> _pickIdDocument() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _idDocument = File(picked.path));
    }
  }

  void _submitForm() {
    setState(() {
      _nameTouched = true;
      _mobileTouched = true;
      _otpTouched = true;
      _aadharTouched = true;
      _locationTouched = true;
      _emergencyTouched = true;
    });

    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Form submitted successfully!')),
      );
    }
  }

  @override
  void dispose() {
    _nameFocus.dispose();
    _mobileFocus.dispose();
    _otpFocus.dispose();
    _aadharFocus.dispose();
    _locationFocus.dispose();
    _emergencyContactFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("South India Farmers Association", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 93, 213, 97),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade300,
                  blurRadius: 10,
                  spreadRadius: 2,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildBoxedTextField(
                    controller: _nameController,
                    focusNode: _nameFocus,
                    hint: "Full Name",
                    touched: _nameTouched,
                    validator: (value) => value!.isEmpty ? 'Please enter your name' : null,
                  ),
                  SizedBox(height: 10),
                  _buildBoxedTextField(
                    controller: _mobileController,
                    focusNode: _mobileFocus,
                    hint: "Mobile Number",
                    keyboardType: TextInputType.number,
                    touched: _mobileTouched,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return 'Enter your mobile number';
                      if (value.length < 10) return 'Mobile number must be 10 digits';
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  _buildBoxedTextField(
                    controller: _otpController,
                    focusNode: _otpFocus,
                    hint: "OTP",
                    keyboardType: TextInputType.number,
                    touched: _otpTouched,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    validator: (value) => value!.isEmpty ? 'Enter OTP' : null,
                  ),
                  SizedBox(height: 10),
                  _buildBoxedTextField(
                    controller: _aadharController,
                    focusNode: _aadharFocus,
                    hint: "Aadhar Number",
                    keyboardType: TextInputType.number,
                    touched: _aadharTouched,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(16),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return 'Enter your Aadhar number';
                      if (value.length < 16) return 'Aadhar number must be 16 digits';
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  _buildBoxedTextField(
                    controller: _emergencyContactController,
                    focusNode: _emergencyContactFocus,
                    hint: "Emergency Contact",
                    keyboardType: TextInputType.number,
                    touched: _emergencyTouched,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(10),
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) return 'Enter emergency contact';
                      if (value.length < 10) return 'Emergency contact must be 10 digits';
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  _buildRadioGroup<String>(
                    label: 'Gender',
                    value: _gender,
                    options: ['Male', 'Female'],
                    onChanged: (val) => setState(() => _gender = val),
                  ),
                  _buildRadioGroup<String>(
                    label: 'Marital Status',
                    value: _maritalStatus,
                    options: ['Married', 'Single', 'Widow', 'Separated'],
                    onChanged: (val) => setState(() => _maritalStatus = val),
                  ),
                  _buildRadioGroup<String>(
                    label: 'Religion',
                    value: _religion,
                    options: ['Hindu', 'Christianity', 'Islam', 'Other'],
                    onChanged: (val) => setState(() => _religion = val),
                  ),
                  _buildDropdownField(),
                  _buildBoxedTextField(
                    controller: _locationController,
                    focusNode: _locationFocus,
                    hint: "Location",
                    touched: _locationTouched,
                    validator: (value) => value!.isEmpty ? 'Please enter location' : null,
                  ),
                  SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _bloodGroup,
                    hint: Text("Select Blood Group"),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                    items: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
                        .map((val) => DropdownMenuItem<String>(value: val, child: Text(val)))
                        .toList(),
                    onChanged: (val) => setState(() => _bloodGroup = val),
                    validator: (value) => value == null ? 'Please select blood group' : null,
                  ),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _pickImage,
                    icon: Icon(Icons.photo),
                    label: Text(_profileImage == null ? "Upload Photo" : "Change Photo"),
                  ),
                  if (_profileImage != null)
                    Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Image.file(_profileImage!, height: 100),
                    ),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _pickIdDocument,
                    icon: Icon(Icons.attach_file),
                    label: Text(_idDocument == null ? "Upload ID Document" : "Change ID Document"),
                  ),
                  SizedBox(height: 30),
                  Center(
                    child: ElevatedButton(
                      onPressed: _submitForm,
                      child: Text('Submit', style: TextStyle(color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 93, 213, 97),
                        padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                        textStyle: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBoxedTextField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String hint,
    required bool touched,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
  }) {
    bool showHint = !focusNode.hasFocus && controller.text.isEmpty;
    String? errorText = touched ? validator?.call(controller.text) : null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (errorText != null)
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 4),
            child: Text(errorText, style: TextStyle(color: Colors.red, fontSize: 13)),
          ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(color: Colors.grey.shade200, blurRadius: 6, offset: Offset(0, 3)),
            ],
          ),
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: TextFormField(
            controller: controller,
            focusNode: focusNode,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            decoration: InputDecoration(
              hintText: showHint ? hint : '',
              border: InputBorder.none,
            ),
            onTap: () => setState(() {}),
            onChanged: (_) => setState(() {}),
          ),
        ),
      ],
    );
  }

  Widget _buildRadioGroup<T>({
    required String label,
    required T? value,
    required List<T> options,
    required void Function(T?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(label, style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        Wrap(
          spacing: 15,
          children: options
              .map((option) => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Radio<T>(value: option, groupValue: value, onChanged: onChanged),
                      Text(option.toString()),
                    ],
                  ))
              .toList(),
        ),
        SizedBox(height: 10),
      ],
    );
  }

  Widget _buildDropdownField() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(8),
        ),
        child: DropdownButtonFormField<String>(
          value: _occupation,
          hint: Text("Select Occupation"),
          decoration: InputDecoration(border: InputBorder.none),
          items: ["Business", "Agriculture", "Agri Labour", "Skill Labour"]
              .map((String val) => DropdownMenuItem<String>(
                    value: val,
                    child: Text(val),
                  ))
              .toList(),
          onChanged: (val) {
            setState(() {
              _occupation = val;
              if (val == 'Skill Labour') {
                _showSkillDialog();
              } else {
                _skill = null; 
              }
            });
          },
        ),
      ),
      
      if (_occupation == 'Skill Labour' && _skill != null && _skill!.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 8.0, left: 10.0),
          child: Text(
            'Entered Skill: $_skill',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            textAlign: TextAlign.left,
          ),
        ),
      SizedBox(height: 20), 
    ],
  );
}

  

  void _showSkillDialog() {
    final skillController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Enter Skill"),
        content: TextField(
          controller: skillController,
          decoration: InputDecoration(hintText: "Enter skill"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => _skill = skillController.text);
              Navigator.of(ctx).pop();
            },
            child: Text("OK"),
          ),
        ],
      ),
    );
  }
}
