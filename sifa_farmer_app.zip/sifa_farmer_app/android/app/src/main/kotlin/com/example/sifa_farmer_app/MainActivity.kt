package com.example.sifa_farmer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
